export const hasQueryString = url => /[?&]/.test(url);
