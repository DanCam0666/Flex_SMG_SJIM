export const limit = (value, min, max) => Math.max(Math.min(max, value), min);
