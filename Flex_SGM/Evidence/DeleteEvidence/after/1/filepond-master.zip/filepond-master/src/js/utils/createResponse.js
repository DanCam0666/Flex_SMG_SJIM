export const createResponse = (type, code, body, headers) => ({
    type,
    code,
    body,
    headers
});