export const lowerCaseFirstLetter = string =>
    string.charAt(0).toLowerCase() + string.slice(1);
